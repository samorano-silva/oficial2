import React from 'react';
import { Redirect } from 'react-router';

class About extends React.Component {
    constructor(props) {
        super(props);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.alterarNome = this.alterarNome.bind(this);
        this.alterarSobrenome = this.alterarSobrenome.bind(this);
        this.alterarEmail = this.alterarEmail.bind(this);
        this.alterarCpf = this.alterarCpf.bind(this);
        this.alterarPag = this.alterarPag.bind(this);
        this.alterarCn = this.alterarCn.bind(this);
        this.alterarNC = this.alterarNC.bind(this);
        this.alterarDE = this.alterarDE.bind(this);


    }
    state = {
        nome: '',
        sobrenome: '',
        cpf: '',
        email: ' ',
        Pag: '',
        NCartao: '',
        CNcartao: '',
        DE: '',
        cvv: '',
        redirect: false,


        address: {

            cep: "",
            city: "",
            neighborhood: "",
            state: "",
            street: ""
        },
        cepInput: ""

    }

    onInputChange(event) {
        this.setState({
            cepInput: event.target.value
        })
    }

    alterarNome = (event) => {

        this.setState({ nome: event.target.value });
    }

    alterarSobrenome = (event) => {

        this.setState({ sobrenome: event.target.value });
    }


    alterarEmail = (event) => {
        this.setState({ email: event.target.value });
    }

    alterarCpf = (event) => {
        this.setState({ cpf: event.target.value });
    }


    

    alterarPag = (event) => {
        this.setState({ Pag: event.target.value });

    }

    alterarCn = (event) => {

        this.setState({ NCartao: event.target.value });
    }

    alterarNC = (event) => {

        this.setState({ CNartao: event.target.value });
    }

    alterarDE = (event) => {

        this.setState({ DE: event.target.value });
    }

    alterarCVV = (event) => {

        this.setState({ cvv: event.target.value });
    }


    handleSubmit(event) {
        fetch(`http://localhost:3001/cep?value=${this.state.cepInput}`)
            .then(
                res => res.json()
            ).then(addressFromApi => {
                this.setState({
                    address: addressFromApi
                })
                
                this.setState({
                    address: ({ city: this.state.address.city})
                })


            })

            .catch(error => {
                console.log(error);
            })
            ;

        event.preventDefault();
    }



    chamaAbout = () => {
        this.setState({
            redirect: true
        })
    }



    render() {

        if (this.state.redirect) {
            return <Redirect to="/confirma" />

        }
        else {

            return (
                <div>
                    <div className="Logo">
                        <h2>Realizar Cadastro<br/><br/><br/></h2>
                    </div>


                    <form onSubmit={this.handleSubmit}>

                        <div>
                            <h4>Nome: <br/></h4>
                            <input type='text' className='form-control' name='nome' placeholder=' Digite o seu nome!' required value={this.state.nome} onChange={this.alterarNome} />

                        </div>

                        <div>
                            <h4>Sobrenome: <br/></h4>
                            <input type='text' className='form-control' name='nome' placeholder=' Digite o seu sobrenome!' required value={this.state.sobrenome} onChange={this.alterarSobrenome} />

                        </div>


                        <div className='email'>
                            <label>
                                <h4>E-mail:<br/> </h4>
                                <input type='email' className='form-control' name='email' placeholder='Por exemplo mauro@email.com' required value={this.state.email} onChange={this.alterarEmail} />
                            </label>
                        </div>


                        <div className='CPF'>
                            <label>
                                <h4>Cpf:<br/> </h4>
                                <input type='text' className='form-control' name='CPF' placeholder='Por exemplo: 000.000.000-00' required value={this.state.cpf} onChange={this.alterarCpf} />
                            </label>
                        </div>


                        <div>
                            <label>Cep:<br/> </label>
                            <input onChange={event => this.onInputChange(event)} />

                        </div>

                        <div>
                            <label>Cidade:<br/> </label>
                            <input onChange={event => this.onInputChange(event)} />
                        </div>

                        <div>
                            <label>Vizinhaça:<br/> </label>
                            <input onChange={event => this.onInputChange(event)} />
                        </div>

                        <div>
                            <label>Estado:<br/> </label>
                            <input onChange={event => this.onInputChange(event)} />
                        </div>

                        <div>
                            <label>Rua:<br/> </label>
                            <input onChange={event => this.onInputChange(event)} />
                        </div>

                        <h2>Selecione a Forma De Pagamento <br/><br/><br/></h2>
                        <div className="Pagamento">
                            <label> <h4>Pagamento: </h4> </label>
             &nbsp;<select value={this.state.Pag} onChange={this.alterarPag} name="Pagamento" required>
                                <option value="">Selecione</option>
                                <option value="Cartão de credito">Cartão de crédito</option>
                                <option value="Cartão de debito">Cartão de débito</option>
                                <option value="PayPal">PayPal</option>
                            </select>
                        </div>

                        <div>
                            <h4>Nome: <br/></h4>
                            <input type='text' className='form-control' name='NCartao' placeholder='Digite o nome como mostra no cartão' required value={this.state.NCartao} onChange={this.alterarCn} />
                        </div>

                        <div>
                            <h4>Número do cartão de crédito:<br/> </h4>
                            <input type='text' className='form-control' name='CNartao' placeholder='' required value={this.state.CNcartao} onChange={this.alterarCn} />
                        </div>

                        <div>
                            <h4>Data de Validade: <br/> </h4>
                            <input type='text' className='form-control' name='Cartao' placeholder='' required value={this.state.DE} onChange={this.alterarDE} />
                        </div>

                        <div>
                            <h4>CVV:<br/> </h4>
                            <input type='text' className='form-control' name='Cartao' placeholder='' required value={this.state.nome} onChange={this.alterarNome} />
                        </div>



                        <input type="submit" value="CONFIRMAR COMPRA" onClick={() => this.chamaAbout()}/>
                    </form>

                </div >
            )

        }

    };
}

export default About;
