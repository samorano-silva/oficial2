import React, {useState} from 'react';
import imagem1 from'../images/imagem1.jpg';
import imagem2 from'../images/imagem2.jpg';
import imagem3 from'../images/imagem3.jpg';
import imagem0 from'../images/imagem0.jpg';
import { connect } from 'react-redux';
import { addBasket } from'../actions/addAction';




const Home =(props) => {
    console.log(props);
    const[basketNumbers, serBasketNumbers] = useState(0)

    const addToBasket = () => {
        serBasketNumbers(basketNumbers + 1);
    };



    return(
        <div className="container">
            <div className="image">
                <img src={imagem0} alt="Imagem0" />
                <h5>Produto 1 <br/></h5>
                <h5>$15,00</h5>
                <a onClick={ () => props.addBasket('imagem0')} className="addCart cart0" href="#">Carrinho</a>
            </div>
            <div className="image">
                <img src={imagem1} alt="imagem1" />
                <h5>Produto 2</h5>
                <h5> $10,00<br/></h5>
                <a onClick={ () => props.addBasket('imagem1')} className="addCart cart1" href="#">Carrinho</a>
            </div>
            <div className="image">
                <img src={imagem2} alt="imagem2" />
                <h5>Produto 3 <br/></h5>
                <h5>$20,00</h5>
                <a onClick={ () => props.addBasket('imagem2')} className="addCart cart2" href="#">Carrinho</a>
            </div>
            <div className="image">
                <img src={imagem3} alt="imagem3" />
                <h5>Produto 4 <br/></h5>
                <h5>$50,00</h5>
                <a onClick={ () => props.addBasket('imagem3')} className="addCart cart3" href="#">Carrinho</a>
            </div>
            
        </div>
    );

}

export default connect(null,{ addBasket } )(Home);