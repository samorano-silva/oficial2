import React from 'react';
import { Redirect } from 'react-router';

function Confirmado(){
     return (
            <h3>COMPRA FOI REALIZADA COM SUCESSO <br/><br/>
            Aguarde Nosso Gmail De Confirmação!
            </h3>
            
    )
    
    
}

export default Confirmado;