import {ADD_PRODUCT_BASKET} from'./types.js';



export const addBasket =(productName) => {
    return(dispatch) =>{
        console.log("Adicionado No Carrinho");
        console.log("produto: ", productName);
        dispatch({
            type: ADD_PRODUCT_BASKET,
            payload: productName
        });

    }
}