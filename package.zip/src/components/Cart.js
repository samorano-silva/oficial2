import React, { Fragment } from'react';
import {connect} from'react-redux';
import { BrowserRouter, Link, Switch } from 'react-router-dom'

import About from '../components/about'
import imagem1 from'../images/imagem1.jpg';
import imagem2 from'../images/imagem2.jpg';
import imagem3 from'../images/imagem3.jpg';
import imagem0 from'../images/imagem0.jpg';
import { Redirect, Router, Route } from 'react-router-dom';



function Cart({basketProps}){
    
    function chamaForm (){
        this.setState({
            redirect: true
        })
    }
    


    console.log(basketProps);

    let productsInCart = [];

    Object.keys(basketProps.products).forEach(function(item){
        console.log(item);
        console.log(basketProps.products[item].inCart );
        if(basketProps.products[item].inCart){
            productsInCart.push(basketProps.products[item])
        }
        console.log(productsInCart);
       
    });

    const productImages = [imagem0,imagem1,imagem2,imagem3 ]

    productsInCart = productsInCart.map ((product,index) => {
        
        console.log("Meu Produto");
        console.log(product);
        return (
            <Fragment>
                    <ion-icon name="arrow-back-circle-outline"></ion-icon>
                    <div className="product"><ion-icon name="close-circle"></ion-icon><img src={productImages[index]} />
                        <span className="sm-hide">{product.name}</span>
                    </div>
                <div className="price sm-hide">${product.price},00</div>
                <div className="quantity">
                    <ion-icon className="decrase" name="arrow-back-circle-outline"></ion-icon>
                        <span>{product.numbers}</span>
                    <ion-icon className="increase" name="arrow-forward-circle-outline"></ion-icon>
                </div>
                <div className="total">${product.numbers*product.price},00</div>
            </Fragment>
        )
    });

    return(
        <div className="container-products">
            <div className="container-header">
                <h5 className="product-title">PRODUTOS</h5>
                <h5 className="price sm-hide">Preço</h5>
                <h5 className="quantity">Quantidade</h5>
                <h5 className="total">Total</h5>
            </div>
            <div className="products">
                {productsInCart}
            </div>
            <div className="basketTotalContainer">
                
                <h4 className="bascketTotal">{basketProps.carCost}</h4>
                <Link to='/about'><button>COMPRAR</button></Link>
                
                
            </div>
        </div>
    );
}

const mapStateToProps = state => ({
    basketProps: state.basketState
});

export default connect(mapStateToProps) (Cart);